import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum

set_option linter.style.longLine false
set_option linter.style.emptyLine false

/-!
# Module: Bipartite Quantum Interference Bound

* Author: José Ignacio Peinador Sala
* Artifact DOI: https://doi.org/10.5281/zenodo.19284510
* Level: N1 Certified (0 sorry assertions, 0 ad-hoc axioms)
-/

namespace PRBM.Quantum

theorem bipartite_interference_bound (channel_1 channel_5 total : ℚ)
    (h_total : total = 1)
    (h_sym : channel_1 = channel_5)
    (h_sum : channel_1 + channel_5 = total) :
    channel_1 * channel_5 = 1 / 4 := by
  rw [h_total] at h_sum
  rw [← h_sym] at h_sum
  have h_val : channel_1 = 1 / 2 := by linarith
  rw [← h_sym, h_val]
  norm_num

end PRBM.Quantum
