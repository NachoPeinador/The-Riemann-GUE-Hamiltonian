import Mathlib.Tactic.NormNum

set_option linter.style.longLine false
set_option linter.style.emptyLine false

/-!
# Module 8: Non-Ergodic Phase Bound

* Author: José Ignacio Peinador Sala
* Artifact DOI: https://doi.org/10.5281/zenodo.19284510
* Level: N1 Certified (0 sorry assertions, 0 ad-hoc axioms)
-/

namespace PRBM.Topology

theorem non_ergodic_phase_bound (bipartite_limit ergodic_limit : ℚ)
    (h_bip : bipartite_limit = 1 / 4)
    (h_erg : ergodic_limit = 1) :
    bipartite_limit < ergodic_limit := by
  rw [h_bip, h_erg]
  norm_num

end PRBM.Topology
