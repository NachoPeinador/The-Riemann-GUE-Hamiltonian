import Mathlib.Tactic.NormNum

set_option linter.style.longLine false
set_option linter.style.emptyLine false

/-!
# Module: Kato-Rellich Self-Adjointness Interval Certification

* Author: José Ignacio Peinador Sala
* Artifact DOI: https://doi.org/10.5281/zenodo.19284510
* Level: N1 Certified (0 sorry assertions, 0 ad-hoc axioms)
-/

namespace PRBM.Spectral

def is_extended_chaotic_phase (nu : ℚ) : Prop :=
  (2 * nu > 1) ∧ (nu < 1)

theorem prbm_kato_rellich_regime (nu : ℚ) (h : nu = 3 / 4) :
    is_extended_chaotic_phase nu := by
  rw [h]
  dsimp [is_extended_chaotic_phase]
  constructor
  · norm_num
  · norm_num

end PRBM.Spectral
