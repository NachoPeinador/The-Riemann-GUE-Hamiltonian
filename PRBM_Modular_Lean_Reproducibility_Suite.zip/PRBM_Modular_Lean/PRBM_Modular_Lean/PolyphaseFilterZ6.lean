import Mathlib.Data.ZMod.Basic
import Mathlib.Tactic.FinCases

set_option linter.style.longLine false
set_option linter.style.emptyLine false

/-!
# Module 11: Polyphase Stopband Annihilation
# Demonstrates that intermediate channels (2, 3, 4) are topologically blocked

- Author: José Ignacio Peinador Sala
- Artifact DOI: https://doi.org/10.5281/zenodo.19284510
- Level: N1 Certified
-/

namespace PRBM.Topology

def polyphase_eval (d : ZMod 6) : ZMod 6 :=
  d * (d - 2) * (d - 3) * (d - 4)

/-- Certifies the annihilation of all non-coprime channels --/
theorem polyphase_stopband (d : ZMod 6) (hd : ¬ Nat.Coprime d.val 6) :
    polyphase_eval d = 0 := by
  fin_cases d <;> revert hd <;> decide

def spectral_mask (d : ZMod 6) : ZMod 6 :=
  if d = 1 ∨ d = 5 then 1 else 0

/-- Certifies that the mask only permits d=1 and its chiral reflection d=5 --/
theorem prbm_chiral_consistency (d : ZMod 6) :
    (spectral_mask d = 1) ↔ Nat.Coprime d.val 6 := by
  fin_cases d <;> decide

end PRBM.Topology
