import Mathlib.Data.Nat.Totient
import Mathlib.Tactic.NormNum

set_option linter.style.longLine false
set_option linter.style.emptyLine false

/-!
# Module: Channel Density Contraction Hierarchy

* Author: José Ignacio Peinador Sala
* Artifact DOI: https://doi.org/10.5281/zenodo.19284510
* Level: N1 Certified (0 sorry assertions, 0 ad-hoc axioms)
-/

namespace PRBM.Topology

noncomputable def density (m : ℕ) : ℚ := (Nat.totient m : ℚ) / (m : ℚ)

theorem strict_channel_contraction_hierarchy :
    density 30 < density 6 ∧ density 6 < density 2 ∧ density 2 < 1 := by
  dsimp [density]
  have h30 : Nat.totient 30 = 8 := rfl
  have h6 : Nat.totient 6 = 2 := rfl
  have h2 : Nat.totient 2 = 1 := rfl
  rw [h30, h6, h2]
  constructor
  · norm_num
  · constructor
    · norm_num
    · norm_num

end PRBM.Topology
