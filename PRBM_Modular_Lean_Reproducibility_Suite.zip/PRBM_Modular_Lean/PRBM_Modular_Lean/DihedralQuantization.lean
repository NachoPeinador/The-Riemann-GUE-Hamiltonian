import Mathlib.Data.ZMod.Basic
import Mathlib.Tactic.Ring

set_option linter.style.longLine false
set_option linter.style.emptyLine false

/-!
# Module 10: Dihedral Quantization & Chiral Involution
# Justifies the algebraic constraint on k_min for PRBM scaling

- Author: José Ignacio Peinador Sala
- Artifact DOI: https://doi.org/10.5281/zenodo.19284510
- Level: N1 Certified
-/

namespace PRBM.Algebra

/-- Channel 5 acts strictly as the chiral reflection involution (-1) --/
theorem c5_is_reflection : (5 : ZMod 6) = -1 := rfl

theorem channel_5_generates_inversion (x : ZMod 6) : 5 * x = -x := by
  calc 5 * x
    _ = (-1 : ZMod 6) * x := by rw [← c5_is_reflection]
    _ = -x := by ring

theorem channel_5_is_involution (x : ZMod 6) : 5 * (5 * x) = x := by
  rw [channel_5_generates_inversion, channel_5_generates_inversion, neg_neg]

end PRBM.Algebra
