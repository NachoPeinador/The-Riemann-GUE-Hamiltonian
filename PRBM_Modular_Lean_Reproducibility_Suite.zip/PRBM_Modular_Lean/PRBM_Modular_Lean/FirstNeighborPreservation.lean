import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Linarith

set_option linter.style.longLine false
set_option linter.style.emptyLine false

/-!
# Module 9: First-Neighbor Preservation & Local Degree Lower Bound
# Appendix D.1 (Lemma D.1) in Manuscript

- Author: José Ignacio Peinador Sala
- Artifact DOI: https://doi.org/10.5281/zenodo.19284510
- Level: N1 Certified (0 sorry assertions, 0 ad-hoc axioms)
-/

namespace PRBM.Topology

/-- Weight function for distance d = 1 at nu = 0.75: w_1 = 2 * 1^(-1.5) = 2 --/
def first_neighbor_weight (nu : ℚ) : ℚ := 2

/--
Lemma D.1 (Local degree contribution):
Certifies that any mask preserving first-neighbor hopping (Xi(1) = 1)
guarantees an immediate non-zero local degree base contribution of exactly 2,
independent of long-range channel density or modulus m.
--/
theorem first_neighbor_degree_guarantee (Xi_1 : ℚ) (h_pres : Xi_1 = 1) :
    Xi_1 * first_neighbor_weight (3/4) = 2 := by
  rw [h_pres]
  dsimp [first_neighbor_weight]
  norm_num

/--
Certifies that removing first-neighbor hopping (Xi(1) = 0) completely
annihilates the local short-range connectivity term.
--/
theorem first_neighbor_removal_annihilation (Xi_1 : ℚ) (h_rem : Xi_1 = 0) :
    Xi_1 * first_neighbor_weight (3/4) = 0 := by
  rw [h_rem]
  dsimp [first_neighbor_weight]
  norm_num

end PRBM.Topology
