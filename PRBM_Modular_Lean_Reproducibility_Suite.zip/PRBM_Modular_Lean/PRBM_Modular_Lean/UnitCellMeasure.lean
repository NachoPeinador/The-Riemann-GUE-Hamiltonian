import Mathlib.Data.Nat.GCD.Basic
import Mathlib.Data.Nat.Totient
import Mathlib.Tactic.NormNum

set_option linter.style.longLine false
set_option linter.style.emptyLine false

/-!
# Module: Unit Cell Measure & Totient Channel Density Ceiling

* Author: José Ignacio Peinador Sala
* Artifact DOI: https://doi.org/10.5281/zenodo.19284510
* Level: N1 Certified (0 sorry assertions, 0 ad-hoc axioms)
-/

namespace PRBM.Sieve

def PRBM_mask (d : ℕ) : ℚ :=
  if d.gcd 6 = 1 then 1 else 0

theorem prbm_unit_cell_measure :
    PRBM_mask 1 + PRBM_mask 2 + PRBM_mask 3 +
    PRBM_mask 4 + PRBM_mask 5 + PRBM_mask 6 = 2 := by
  have h1 : PRBM_mask 1 = 1 := rfl
  have h2 : PRBM_mask 2 = 0 := rfl
  have h3 : PRBM_mask 3 = 0 := rfl
  have h4 : PRBM_mask 4 = 0 := rfl
  have h5 : PRBM_mask 5 = 1 := rfl
  have h6 : PRBM_mask 6 = 0 := rfl
  rw [h1, h2, h3, h4, h5, h6]
  norm_num

theorem prbm_asymptotic_density :
    (PRBM_mask 1 + PRBM_mask 2 + PRBM_mask 3 +
     PRBM_mask 4 + PRBM_mask 5 + PRBM_mask 6) / 6 = 1 / 3 := by
  rw [prbm_unit_cell_measure]
  norm_num

noncomputable def max_channel_density (m : ℕ) : ℚ :=
  (Nat.totient m : ℚ) / (m : ℚ)

theorem channel_density_bound_Z6Z : max_channel_density 6 = 1 / 3 := by
  dsimp [max_channel_density]
  have h_tot : Nat.totient 6 = 2 := rfl
  rw [h_tot]
  norm_num

end PRBM.Sieve
