import Mathlib.Data.Nat.GCD.Basic

set_option linter.style.longLine false
set_option linter.style.emptyLine false

/-!
# Module: NCG Chiral Superselection & Modular Phase Absorption

* Author: José Ignacio Peinador Sala
* Artifact DOI: https://doi.org/10.5281/zenodo.19284510
* Level: N1 Certified (0 sorry assertions, 0 ad-hoc axioms)
-/

namespace PRBM.NCG

theorem wheel_channels_structure (d : ℕ) (h : Nat.Coprime d 6) :
    d % 6 = 1 ∨ d % 6 = 5 := by
  have h_mod : d % 6 < 6 := Nat.mod_lt d (by decide)
  match h_eq : d % 6 with
  | 0 =>
    exfalso
    have h2 : 2 ∣ d := by omega
    have h6 : 2 ∣ 6 := by decide
    have h_gcd : 2 ∣ Nat.gcd d 6 := Nat.dvd_gcd h2 h6
    have h_coprime : Nat.gcd d 6 = 1 := h
    omega
  | 1 => left; rfl
  | 2 =>
    exfalso
    have h2 : 2 ∣ d := by omega
    have h6 : 2 ∣ 6 := by decide
    have h_gcd : 2 ∣ Nat.gcd d 6 := Nat.dvd_gcd h2 h6
    have h_coprime : Nat.gcd d 6 = 1 := h
    omega
  | 3 =>
    exfalso
    have h3 : 3 ∣ d := by omega
    have h6 : 3 ∣ 6 := by decide
    have h_gcd : 3 ∣ Nat.gcd d 6 := Nat.dvd_gcd h3 h6
    have h_coprime : Nat.gcd d 6 = 1 := h
    omega
  | 4 =>
    exfalso
    have h2 : 2 ∣ d := by omega
    have h6 : 2 ∣ 6 := by decide
    have h_gcd : 2 ∣ Nat.gcd d 6 := Nat.dvd_gcd h2 h6
    have h_coprime : Nat.gcd d 6 = 1 := h
    omega
  | 5 => right; rfl
  | n + 6 => exfalso; omega

theorem ncg_chiral_phase_absorption (d : ℕ) (h : Nat.Coprime d 6) :
    ∃ k : ℕ, (d * k) % 6 = 1 := by
  match wheel_channels_structure d h with
  | Or.inl h1 =>
    use 1
    omega
  | Or.inr h5 =>
    use 5
    omega

end PRBM.NCG
