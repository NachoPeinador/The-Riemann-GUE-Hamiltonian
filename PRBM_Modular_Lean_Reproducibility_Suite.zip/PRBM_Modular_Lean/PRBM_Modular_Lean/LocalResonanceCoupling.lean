import Mathlib.Data.Real.Sqrt
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Positivity

set_option linter.style.longLine false
set_option linter.style.emptyLine false

/-!
# Module: Local Resonance Coupling Bound

* Author: José Ignacio Peinador Sala
* Artifact DOI: https://doi.org/10.5281/zenodo.19284510
* Level: N1 Certified (0 sorry assertions, 0 ad-hoc axioms)
-/

namespace PRBM.QuantumChaos

theorem prbm_critical_coupling (epsilon D : ℝ) (heps : 0 ≤ epsilon)
    (hD : D = 2 * Real.pi) (h_res : 2 * epsilon^2 = D^2) :
    epsilon = Real.pi * Real.sqrt 2 := by
  have h_rhs_pos : 0 ≤ Real.pi * Real.sqrt 2 := by positivity
  have h_sq : epsilon ^ 2 = (Real.pi * Real.sqrt 2) ^ 2 := by
    calc epsilon ^ 2 = D ^ 2 / 2 := by linarith [h_res]
      _ = (2 * Real.pi) ^ 2 / 2 := by rw [hD]
      _ = Real.pi ^ 2 * 2 := by ring
      _ = (Real.pi * Real.sqrt 2) ^ 2 := by
        rw [mul_pow, Real.sq_sqrt (by norm_num)]
  have h_abs := congrArg Real.sqrt h_sq
  rw [Real.sqrt_sq heps, Real.sqrt_sq h_rhs_pos] at h_abs
  exact h_abs

end PRBM.QuantumChaos
